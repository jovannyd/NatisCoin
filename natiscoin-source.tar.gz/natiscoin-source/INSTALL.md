Building NatisCoin
=============

See doc/build-*.md for instructions on building the various
elements of the NatisCoin Core reference implementation of NatisCoin.
