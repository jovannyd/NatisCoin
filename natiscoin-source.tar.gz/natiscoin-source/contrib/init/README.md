Sample configuration files for:

SystemD: natiscoind.service
Upstart: natiscoind.conf
OpenRC:  natiscoind.openrc
         natiscoind.openrcconf
CentOS:  natiscoind.init
OS X:    org.natiscoin.natiscoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
