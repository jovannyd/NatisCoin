Development moved to https://gitlab.com/blacknet-ninja

https://natiscoin.org/ aims to continue on NatisCoin chain.
